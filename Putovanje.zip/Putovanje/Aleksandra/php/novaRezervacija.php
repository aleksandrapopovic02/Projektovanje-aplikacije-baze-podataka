<?php

include("baza.php");

$ime = $_POST['ime'];
$prezime = $_POST['prezime'];
$br_telefona = $_POST['br_telefona'];
$email = $_POST['email'];
$destinacija = $_POST['destinacija'];

if ($mysqli->connect_error) {
    die("Neuspjelo povezivanje s bazom podataka: " . $mysqli->connect_error);
}

$statement = $mysqli->prepare("INSERT INTO rezervacija (ime, prezime, br_telefona, email, destinacija) VALUES (?, ?, ?, ?, ?)");

if (!$statement) {
    die("Greška prilikom pripreme upita: " . $mysqli->error);
}

$statement->bind_param("sssss", $ime, $prezime, $br_telefona, $email,  $destinacija);

if ($statement->execute()) {
    header("Location: ../novaRezervacija.php?success=1");
} else {
    die("Error : (" . $mysqli->errno . ") " . $mysqli->error);
}

$statement->close();
$mysqli->close();
