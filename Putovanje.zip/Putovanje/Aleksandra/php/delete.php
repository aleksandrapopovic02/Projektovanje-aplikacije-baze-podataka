<?php
include("baza.php");


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["delete"])) {

    if (isset($_POST["id"])) {
        $id = $_POST["id"];

        $statement = $mysqli->prepare("DELETE FROM rezervacija WHERE id = ?");
        $statement->bind_param("i", $id);

        if ($statement->execute()) {

            $poruka = "Podaci su uspešno obrisani iz baze.";

            header('Location: ' . $_SERVER['HTTP_REFERER'] . '?poruka=' . urlencode($poruka));
            exit;
        } else {
            echo "Greška prilikom brisanja iz baze: " . $statement->error;
        }


        $statement->close();
    } else {
        echo "Nedostaje ID rezervacije.";
    }
} else {
    echo "Neispravan zahtev za brisanje.";
}

$mysqli->close();
