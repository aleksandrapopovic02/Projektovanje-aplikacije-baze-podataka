<?php

include("baza.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $destinacija = $_POST['destinacija'];
    $datum = $_POST['datum'];
    $trajanje = $_POST['trajanje'];
    $prevoz = $_POST['prevoz'];
    $opis = $_POST['opis'];
    $cena = $_POST['cena'];

    if ($mysqli->connect_error) {
        die("Neuspjelo povezivanje s bazom podataka: " . $mysqli->connect_error);
    }

    $statement = $mysqli->prepare("INSERT INTO ekskurzije (destinacija, datum, trajanje, prevoz, opis, cena) VALUES (?, ?, ?, ?, ?, ?)");

    if (!$statement) {
        die("Greška prilikom pripreme upita: " . $mysqli->error);
    }

    $statement->bind_param("ssisss", $destinacija, $datum, $trajanje, $prevoz, $opis, $cena);

    if ($statement->execute()) {
        header("Location: ../novaEkskurzija.php?success=1");
        exit(); // Dodato da se zaustavi izvršavanje skripte nakon preusmerenja
    } else {
        die("Error : (" . $mysqli->errno . ") " . $mysqli->error);
    }

    $statement->close();
    $mysqli->close();
}
